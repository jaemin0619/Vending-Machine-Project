package Machine;

public class MachineMain {
	
	// ���Ǳ� Main�Լ�
	public static void main(String[] args) {
		
		MachineFrame mcFrame = new MachineFrame("woals!619");
	}
}
