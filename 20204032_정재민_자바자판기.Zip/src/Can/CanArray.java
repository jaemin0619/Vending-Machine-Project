package Can;

import java.util.ArrayList;
import java.util.List;
// ���� ����Ʈ
public class CanArray {
	public static List<Can> canList = new ArrayList<Can>();
}
