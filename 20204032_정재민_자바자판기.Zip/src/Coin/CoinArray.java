package Coin;

import java.util.ArrayList;
import java.util.List;

// �ܵ� ����Ʈ
public class CoinArray {
	public static List<Coin> coinList = new ArrayList<Coin>();
}
